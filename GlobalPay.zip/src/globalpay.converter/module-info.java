module globalpay.converter {
    exports globalpay.converter;
}
