package globalpay.converter;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;

/**
 * GlobalPay Financial Services - simple USD currency converter.
 * Demonstrates exception handling, a ResourceBundle for messages,
 * and a Java module (globalpay.converter).
 */
public class CurrencyConverter {

    // Fixed conversion rates (1 USD = x)
    private static final double USD_TO_EUR = 0.90;
    private static final double USD_TO_MXN = 17.00;

    public static void main(String[] args) {
        // Load the English (US) message file: Messages_en_US.properties
        ResourceBundle messages =
                ResourceBundle.getBundle("Messages", Locale.US);

        Scanner scanner = new Scanner(System.in);

        System.out.println(messages.getString("welcome"));

        try {
            // Step 1: read the amount in USD
            System.out.print(messages.getString("enterAmount") + " ");
            double amount = Double.parseDouble(scanner.nextLine().trim());
            if (amount < 0) {
                throw new NumberFormatException("Negative amount");
            }

            // Step 2: read the target currency
            System.out.print(messages.getString("enterCurrency") + " ");
            String currency = scanner.nextLine().trim().toUpperCase();

            // Step 3: convert using the fixed rates
            double converted;
            switch (currency) {
                case "EUR":
                    converted = amount * USD_TO_EUR;
                    break;
                case "MXN":
                    converted = amount * USD_TO_MXN;
                    break;
                default:
                    throw new IllegalArgumentException("Unsupported currency: " + currency);
            }

            // Step 4: show the result with two decimal places
            String formatted = String.format("%.2f", converted);
            System.out.println(
                    MessageFormat.format(messages.getString("result"), formatted, currency));

        } catch (NumberFormatException e) {
            // Non-numeric (or negative) amount
            System.out.println(messages.getString("invalidAmount"));
        } catch (IllegalArgumentException e) {
            // Currency code is not EUR or MXN
            System.out.println(messages.getString("invalidCurrency"));
        } finally {
            scanner.close();
        }
    }
}
